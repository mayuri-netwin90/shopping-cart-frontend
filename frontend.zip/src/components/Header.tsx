import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

export function Header() {
  const { cartItems } = useCart();
  const itemCount = cartItems.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <header className="border-b p-4 flex items-center justify-between max-w-6xl mx-auto">
      <Link to="/" className="text-xl font-bold">
        MyShop
      </Link>

      <Link to="/cart" className="relative flex items-center gap-1">
        <span>Cart</span>
        {itemCount > 0 && (
          <span className="absolute -top-2 -right-3 bg-blue-600 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
            {itemCount}
          </span>
        )}
      </Link>
    </header>
  );
}